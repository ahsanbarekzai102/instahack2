<p align="center">
<a href="https://instagram.com/sslri"><img title="Made in iran" src="https://img.shields.io/badge/MADE%20IN-IRAN-SCRIPT?colorA=%23ff8100&colorB=%23017e40&colorC=%23ff0000&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://sslri.ir"><img title="Made in IRAN" src="https://img.shields.io/badge/Tool-instahack-green.svg"></a>
<a href="https://sslri.ir"><img title="Version" src="https://img.shields.io/badge/Version-1.0-green.svg?style=flat-square"></a>
<a href="https://youtube.com/sslri"><img title="Maintainence" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>
</p>
<p align="center">
<a href="https://instagram.com/sslri"><img title="instahack" src="https://s16.picofile.com/file/8426004468/logoo.png"></a>
</p>
<p align="center">
<a href="https://github.com/SSLRI"><img title="Github" src="https://img.shields.io/badge/sslri-brightgreen?style=for-the-badge&logo=github"></a>
<a href="https://instagram.com/sslri"><img title="instagram" src="https://img.shields.io/badge/instagram-yousec Hackers-red?style=for-the-badge&logo=instagram"></a>
</p>
<p align="center">
<a href="https://github.com/sslri"><img title="Language" src="https://img.shields.io/badge/Made%20with-Bash-1f425f.svg?v=103"></a>
<a href="https://github.com/sslri"><img title="Followers" src="https://img.shields.io/github/followers/evildevill?color=blue&style=flat-square"></a>
<a href="https://github.com/sslri"><img title="Stars" src="https://img.shields.io/github/stars/evildevill/instahack?color=red&style=flat-square"></a>
<a href="https://github.com/sslri"><img title="Forks" src="https://img.shields.io/github/forks/evildevill/instahack?color=red&style=flat-square"></a>
<a href="https://github.com/sslri"><img title="Watching" src="https://img.shields.io/github/watchers/evildevill/instahack?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/sslri"><img title="Licence" src="https://img.shields.io/badge/License-MIT-blue.svg"></a>
</p>

## ABOUT :

instahack is a bash based script which is officially made to test password strength of instagram account from termux with bruteforce attack and. This tool works on both rooted Android device and Non-rooted Android device. this script can bypass login limiting and it can test infinite number of passwords with a rate of about 1000 passwords/min with 100 attemps at once. 

## AVAILABLE ON ✣ TESTED ON  :

* ✪ Termux

### REQUIREMENTS :
* internet
* php
* storage 400 MB
* ngrok Token

## FEATURES :
* [+]Instagram stable api !
* [+] Updated maintainence !
* [+] tor usage !
* [+] Easy for Beginners !

## INSTALLATION [Termux]ッ :

* `apt-get update -y`
* `apt-get upgrade -y`
* `pkg install python -y`
* `pkg install python2 -y`
* `pkg install git -y`
* `pip install lolcat`
* `git clone https://github.com/sslri/instahack`
* `cd $HOME`
* `ls`
* `cd instahack`
* `ls`
* `bash setup`
* `bash instahack.sh`
```
[+]--Now you need internet connection to continue further process...

[+]--You can select any option by clicking on your keyboard

[+]--Note:- Don't delete any of the scripts included in core files

[+]--new session and start TOR (tor) before starting the attack
```
## USAGE OPTIONS [Termux] :

__AUTO ATTACK__ :
- From this option you can start attack aon default pass list of tool.

__MANUAL ATTACK__ :
- From this option you can select manual pass list and try to attack.

__ABOUT__ :
- From this option you can know more about author.

__UPDATE__ :
- From this option you can update instahack tool if updates are available for that.

__EXIT__ :
- From this option you can exit from tool 


## CONNECT WITH US :

<a href="https://github.com/sslri"><img title="Github" src="https://img.shields.io/badge/sslri-brightgreen?style=for-the-badge&logo=github"></a>
[![Instagram](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://instagram.com/sslri)
[![Instagram](https://img.shields.io/badge/WEBSITE-VISIT-yellow?style=for-the-badge&logo=blogger)](https://sslri.ir)
[![Instagram](https://img.shields.io/badge/LINKEDIN-CONNECT-red?style=for-the-badge&logo=linkedin)](https://linkedin/sslri)
[![Instagram](https://img.shields.io/badge/FACEBOOK-LIKE-red?style=for-the-badge&logo=facebook)](https://facebook.com/saeeddsalari)
[![Instagram](https://img.shields.io/badge/TELEGRAM-CHANNEL-red?style=for-the-badge&logo=telegram)](https://t.me/sslri)
[![Instagram](https://img.shields.io/badge/WHATSAPP-JOINGROUP-red?style=for-the-badge&logo=whatsapp)](https://wa.me/989384491252)

## BUY ME A COFFEE ᵔ.ᵔ :

<p align="center">
<a href="https://l.jeeb.io/YjcwM"><img title="sslri" src="https://camo.githubusercontent.com/ae8af018f80649f3d379eb23dbf59acceaffa24e/68747470733a2f2f6c69626572617061792e636f6d2f6173736574732f776964676574732f646f6e6174652e737667"></a>
</p>

## WARNING : 
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
Guys, if you have any doubts or problems while doing this script, you can contact me and I will definitely help.
